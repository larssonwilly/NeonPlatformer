package com.ludum.src.interfaces;

public enum ObjectId 
{
	
	Player(1),
	Moon_Top(2),
	Moon_Mid(3),
	End_Block(4),
	YStar(5),
	GStar(6),
	Lava(7),
	LavaBase(8),
	Coin(9),
	Blood(10);
	
	ObjectId(int id)
	{
	
	}
	
}
